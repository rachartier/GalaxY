#ifndef __PORTAL_H_GUARD__
#define __PORTAL_H_GUARD__

#include "planet.h"
#include "starsystem.h"

Planet createPortal(void);

#endif /* __PORTAL_H_GUARD__ */